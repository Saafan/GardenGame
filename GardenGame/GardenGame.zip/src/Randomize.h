#pragma once
#include <random>

int Randomize(int min = 0, int max = 1);
float Randomize(float min = 0.0f, float max = 1.0f);