#pragma once

class Object
{

};
